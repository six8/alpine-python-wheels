# coding=utf-8
#
# License: http://jkeyes.mit-license.org/
#
from intercom import *


def test_wildcard_import():
    pass
