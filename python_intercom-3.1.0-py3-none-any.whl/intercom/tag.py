# -*- coding: utf-8 -*-

from intercom.traits.api_resource import Resource


class Tag(Resource):
    pass
