# -*- coding: utf-8 -*-  # noqa

from intercom.traits.api_resource import Resource


class Job(Resource):
    """A Bulk API Job.

    Ref: https://developers.intercom.io/reference#bulk-job-model
    """
