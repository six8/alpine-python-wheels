# -*- coding: utf-8 -*-
"""Package for operations that can be performed on a resource."""
