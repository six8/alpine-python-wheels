# -*- coding: utf-8 -*-
"""Count Resource."""

from intercom.traits.api_resource import Resource


class Count(Resource):
    """Collection class for Counts."""
