# -*- coding: utf-8 -*-
"""Collection module for Conversations."""
from intercom.traits.api_resource import Resource


class Conversation(Resource):
    """Collection class for Converations."""
