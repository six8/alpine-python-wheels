MIT License
===========

See http://jkeyes.mit-license.org/ for specific license information.
