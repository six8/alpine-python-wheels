python-intercom is written and maintained by John Keyes and various
contributors:

Development Lead
~~~~~~~~~~~~~~~~

- John Keyes <john@keyes.ie> `@jkeyes <https://github.com/jkeyes>`_

Patches and Suggestions
~~~~~~~~~~~~~~~~~~~~~~~

- `vrachnis <https://github.com/vrachnis>`_
- `sdorazio <https://github.com/sdorazio>`_
- `Cameron Maske <https://github.com/cameronmaske>`_
- `Martin-Zack Mekkaoui <https://github.com/mekza>`_
- `Marsel Mavletkulov <https://github.com/marselester>`_
- `Grant McConnaughey <https://github.com/grantmcconnaughey>`_
- `Robert Elliott <https://github.com/greenafrican>`_
- `Jared Morse <https://github.com/jarcoal>`_
- `Rafael <https://github.com/neocortex>`_
- `jacoor <https://github.com/jacoor>`_
- `maiiku <https://github.com/maiiku>`_
- `Piotr Kilczuk <https://github.com/centralniak>`_
- `Forrest Scofield <https://github.com/fscofield>`_
- `Jordan Feldstein <https://github.com/jfeldstein>`_
- `François Voron <https://github.com/frankie567>`_
- `Gertjan Oude Lohuis <https://github.com/gertjanol>`_

Intercom
~~~~~~~~

- `Darragh Curran <https://github.com/darragh>`_
- `Bill de hÓra <https://github.com/dehora>`_
- `Jeff Gardner <https://github.com/erskingardner>`_
