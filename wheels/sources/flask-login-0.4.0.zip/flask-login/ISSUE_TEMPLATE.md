Make sure these boxes are checked before submitting your issue--thank you!

- [ ] Ensure you are using the latest PyPI release.
- [ ] Read the [CHANGES](https://github.com/maxcountryman/flask-login/blob/master/CHANGES) document thoroughly.
- [ ] Provide a clear and simple set of steps to reproduce your issue for others.
